/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * Author: eyjian@qq.com or eyjian@gmail.com
 */
#ifndef ECHO_PACKET_HANDLER_H
#define ECHO_PACKET_HANDLER_H
#include <server/server.h>
MOOON_NAMESPACE_BEGIN

class CEchoPacketHandler : public server::IPacketHandler
{
public:
    CEchoPacketHandler();
    CEchoPacketHandler(server::IConnection* connection);
    virtual ~CEchoPacketHandler();

    // interfaces needed to be implement
    // pure virtual function must be rewrite
private:
    void init();
    
    // reset buffer
    virtual void reset();

    // handle request procedure:
    // 1. get_request_size(), get_request_offset(), get_request_buffer()
    // 2. on_handle_request() do actual work
    // 3. reset() reset buffer
    
    // get request buffer size
    virtual size_t get_request_size() const;

    // get request buffer offset
    virtual size_t get_request_offset() const;

    // get request buffer
    virtual char * get_request_buffer();

    // do request handle
    virtual util::handle_result_t on_handle_request(size_t data_size, server::Indicator & indicator);

    // handler response procedure:
    // 1. get_response_size(), get_response_offset(), get_response_buffer()
    // 2. move_response_offset()
    // 3. on_response_completed()
    // 4. reset()

    // get response buffer size
    virtual size_t get_response_size() const;

    // get response buffer offset
    virtual size_t get_response_offset() const;

    // get response buffer
    virtual const char * get_response_buffer() const;

    // move buffer offset
    virtual void move_response_offset(size_t offset);

    // after finish response
    virtual util::handle_result_t on_response_completed(server::Indicator & indicator);

private:
    char * request_buffer_;
    size_t request_buffer_size_;
    size_t request_buffer_offset_;

    char * response_buffer_;
    size_t response_buffer_size_;
    size_t response_buffer_offset_;
};

MOOON_NAMESPACE_END
#endif // ECHO_PACKET_HANDLER_H
