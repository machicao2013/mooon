/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * Author: eyjian@qq.com or eyjian@gmail.com
 */

#include "echo_packet_handler.h"

MOOON_NAMESPACE_BEGIN

CEchoPacketHandler::CEchoPacketHandler(server::IConnection* connection)
{
    request_buffer_ = NULL;
    request_buffer_size_ = 0;
    request_buffer_offset_ = 0;

    response_buffer_ = NULL;
    response_buffer_size_ = 0;
    response_buffer_offset_ = 0;

    init();
}

CEchoPacketHandler::~CEchoPacketHandler()
{
    delete [] request_buffer_;
    delete [] response_buffer_;
}

void CEchoPacketHandler::init()
{
#define MacMaxBufferSize 1024
    request_buffer_size_ = MacMaxBufferSize;
    request_buffer_ = new char[MacMaxBufferSize];
    request_buffer_offset_ = 0;

    response_buffer_size_ = MacMaxBufferSize;
    response_buffer_ = new char[MacMaxBufferSize];
    response_buffer_offset_ = 0;
}

void CEchoPacketHandler::reset()
{
    request_buffer_offset_ = 0;
    response_buffer_offset_ = 0;
}

size_t CEchoPacketHandler::get_request_size() const
{
    return request_buffer_size_;
}

size_t CEchoPacketHandler::get_request_offset() const
{
    return request_buffer_offset_;
}

char * CEchoPacketHandler::get_request_buffer()
{
    return request_buffer_;
}

util::handle_result_t CEchoPacketHandler::on_handle_request(size_t data_size, server::Indicator & indicator)
{
    if (data_size > request_buffer_size_)
    {
        fprintf(stderr, "on_handle_request failed! data_size(%d)>request_buffer_size_(%d)\n", (int)data_size, (int)request_buffer_size_);
        return util::handle_error;
    }

    int32_t str_len;
    char * str_buf;
    char * cur_buf;

    cur_buf = request_buffer_;

    //str_len = *(int32_t *)cur_buf;
    //cur_buf += sizeof(int32_t);

    //str_buf = new char[str_len + 1];
    //memcpy(str_buf, cur_buf, str_len);
    str_len = data_size;
    str_buf = new char[str_len + 1];
    memcpy(str_buf, cur_buf, str_len);
    str_buf[str_len + 1] = 0;
    fprintf(stderr, "receive(%d): %s\n", strlen(str_buf), str_buf);

    memcpy(response_buffer_, request_buffer_, data_size);

    return util::handle_finish;
}

size_t CEchoPacketHandler::get_response_size() const
{
    return response_buffer_size_;
}

size_t CEchoPacketHandler::get_response_offset() const
{
    return response_buffer_offset_;
}

const char * CEchoPacketHandler::get_response_buffer() const
{
    return response_buffer_;
}

void CEchoPacketHandler::move_response_offset(size_t offset)
{
    response_buffer_offset_ += offset;
}

util::handle_result_t CEchoPacketHandler::on_response_completed(server::Indicator & indicator)
{
    fprintf(stderr, "response(%d): %s\n", strlen(response_buffer_), response_buffer_);
    return util::handle_finish;
}

MOOON_NAMESPACE_END
